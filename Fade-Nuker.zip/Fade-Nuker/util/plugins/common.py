# Fade Nuker was proudly coded by Fishy
# Fade Nuker under the GNU General Public Liscense v2 (1991).

import os, requests, json, sys, platform, ctypes
from time import sleep

THIS_VERSION = "1.3.0"

def clear():
    system = platform.system()
    if system == 'Windows':
        os.system('cls')
    elif system == 'Linux':
        os.system('clear')
    else:
        print('\n')*120
    return

def setTitle(str):
    ctypes.windll.kernel32.SetConsoleTitleW(str+" | Made By Fishy#0608")

def print_slow(str):
    for letter in str:
        sys.stdout.write(letter);sys.stdout.flush();sleep(0.05)


def getheaders(token=None, content_type="application/json"):
    headers = {
        "Content-Type": content_type,
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11"
    }
    if token:
        headers.update({"Authorization": token})
    return headers